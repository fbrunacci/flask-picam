sudo apt-get update
sudo apt-get -y install libharfbuzz0b libfontconfig1

wget https://github.com/iizukanao/picam/releases/download/v1.4.7-dev-4ch/picam-1.4.7-4ch-binary.tar.xz
unxz picam-1.4.7-4ch-binary.tar.xz
tar xvf picam-1.4.7-4ch-binary.tar
mv picam-1.4.7-4ch-binary picam

# Create directories and symbolic links
cat > make_dirs.sh <<'EOF'
#!/bin/bash
DEST_DIR=~/picam
SHM_DIR=/run/shm

mkdir -p $SHM_DIR/rec
mkdir -p $SHM_DIR/hooks
mkdir -p $SHM_DIR/state
mkdir -p $DEST_DIR/archive

ln -sfn $DEST_DIR/archive $SHM_DIR/rec/archive
ln -sfn $SHM_DIR/rec $DEST_DIR/rec
ln -sfn $SHM_DIR/hooks $DEST_DIR/hooks
ln -sfn $SHM_DIR/state $DEST_DIR/state
EOF

chmod +x make_dirs.sh
./make_dirs.sh
chmod +x $DEST_DIR/picam

#python/flask
sudo apt-get -y install python-pip
pip install pgrep flask


